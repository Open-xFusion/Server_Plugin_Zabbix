****************************************************************************
Zabbix Plugin Pack for xFusion Device
****************************************************************************

I. General Information

    Name:     Zabbix Plugin Packsage for xFusion Server
    Function: Query, Monitoring
    Version:  2.9.0


II. Description

    Integrated in the Zabbix software, xFusion Zabbix plug-in is provided as a Zabbix template. Users can directly use it or use it for secondary development. The Zabbix plug-in can be used to monitor the xFusionBMC, HMM.


III. Compatibility Information

<table>
   <tr>
      <td>Managed Object</td>
      <td>Compatible Zabbix Version</td>
      <td><span style="white-space:nowrap;">Version  Dependency&emsp;&emsp;&emsp;&emsp;</span></td>
      <td><span style="white-space:nowrap;">Hardware  Compatibility&emsp;&emsp;&emsp;</span></td>
      <td><span style="white-space:nowrap;">Interface  Protocol&emsp;&emsp;&emsp;&emsp;</span></td>
   </tr>
   <tr>
      <td>xFusionBMC</td>
      <td>Zabbix 7.4</td>
      <td>xFusionBMC 4.01.42 or later</td>
      <td>
        Rack server: 2288H V8;<br/>
        Rack-Scale Server: DH120E V8;
      </td>
      <td>redfish</td>
   </tr>
</table>




VI. Additional Resources

    For more information consult User Guide: https://github.com/Open-xFusion/Server_Plugin_Zabbix/tree/main/docs