****************************************************************************
Zabbix Plugin Pack for xFusion Device
****************************************************************************

I. General Information

    Name:     Zabbix Plugin Packsage for xFusion Server
    Function: Query, Monitoring
    Version:  2.8.0

	
II. Description

    Integrated in the Zabbix software, xFusion Zabbix plug-in is provided as a Zabbix template. Users can directly use it or use it for secondary development. The Zabbix plug-in can be used to monitor the iBMC, HMM.

	
III. Compatibility Information


<table>
   <tr>
      <td>Managed Object</td>
      <td>Compatible Zabbix Version</td>
      <td><span style="white-space:nowrap;">Version  Dependency&emsp;&emsp;&emsp;&emsp;</span></td>
      <td><span style="white-space:nowrap;">Hardware  Compatibility&emsp;&emsp;&emsp;</span></td>
      <td><span style="white-space:nowrap;">Interface  Protocol&emsp;&emsp;&emsp;&emsp;</span></td>
   </tr>
   <tr>
      <td>HMM</td>
      <td>Zabbix 5.4</td>
      <td>HMM V686D or later</td>
      <td>Blade server: E9000(MM910)</td>
      <td>SNMP v2</td>
   </tr>
</table>


	
VI. Additional Resources

    For more information consult User Guide: https://github.com/Open-xFusion/Server_Plugin_Zabbix/tree/main/docs